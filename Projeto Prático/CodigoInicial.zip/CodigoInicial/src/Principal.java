public class Principal{
  public static void main(String[] args){
    Simulator simulator = new Simulator();
    simulator.runLongSimulation();
    //simulator.simulate(300);
  }
}
