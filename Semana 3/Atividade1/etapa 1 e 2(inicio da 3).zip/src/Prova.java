import java.util.Scanner;

public class Prova {
    Questao questao;
    Scanner entrada = new Scanner(System.in);

    Prova() {
        questao = new Questao();
    }

    public void aplicar() {
        int tentativa = 1;
        boolean acertou = false;
        questao.exibirEnunciado();

        while (!acertou && tentativa <= 2) {
            int resposta = entrada.nextInt();

            if (resposta == questao.resultado) {
                acertou = true;
                System.out.printf("Você tentou %d vez(es) e acertou a questão.\n", tentativa);
            } else if (tentativa == 1) {
                System.out.print("Você ganhou mais uma chance! Digite outra resposta para a questão: ");
            }
            tentativa++;
        }

        if (!acertou)
            System.out.println("Você tentou 2 vezes e errou a questão.");
    }
}
