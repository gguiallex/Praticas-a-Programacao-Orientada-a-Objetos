public class App {
    public static void main(String[] args) throws Exception {
        Prova prova1 = new Prova();
        prova1.aplicar();
    }
}
